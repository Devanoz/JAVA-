package main;

import model.Barang;

public interface MyListener {
    public void onClickListener(Barang fruit);
}
